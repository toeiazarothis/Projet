<?php
define('UTILISATEUR','u240317083_admin');
define('PASS','ischoolnotes');
?>
